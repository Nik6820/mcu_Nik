#pragma once

void stdio_task_init();
char* stdio_task_handle();

